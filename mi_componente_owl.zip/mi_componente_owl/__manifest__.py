{
    'name': 'Mi Componente OWL',
    'version': '1.0',
    'summary': 'Módulo interactivo de Lista de Tareas usando OWL en Odoo 17',
    'category': 'Technical',
    'author': 'Laboratorio E-Business',
    'depends': ['base', 'web'],
    'data': [
        'views/todo_menu.xml',
    ],
    'assets': {
        'web.assets_backend': [
            'mi_componente_owl/static/src/js/todo_list.js',
            'mi_componente_owl/static/src/xml/todo_list.xml',
        ],
    },
    'installable': True,
    'application': True,
    'license': 'LGPL-3',
}