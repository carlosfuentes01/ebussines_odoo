/** @odoo-module */
import { Component, useState } from "@odoo/owl";
import { registry } from "@web/core/registry";

class TodoList extends Component {
    static template = "mi_componente_owl.TodoList";

    setup() {
        this.state = useState({
            tasks: [],
            newTask: "",
        });
    }

    onInputChange(e) {
        this.state.newTask = e.target.value;
    }

    onKeyDown(e) {
        if (e.key === "Enter") {
            this.addTask();
        }
    }

    addTask() {
        if (!this.state.newTask || this.state.newTask.trim() === "") return;
        this.state.tasks.push({
            id: Date.now(),
            text: this.state.newTask,
            done: false,
        });
        this.state.newTask = "";
    }

    toggleTask(id) {
        const task = this.state.tasks.find((t) => t.id === id);
        if (task) task.done = !task.done;
    }

    removeTask(id) {
        this.state.tasks = this.state.tasks.filter((t) => t.id !== id);
    }
}

registry.category("actions").add("mi_componente_owl.todo_action", TodoList);
